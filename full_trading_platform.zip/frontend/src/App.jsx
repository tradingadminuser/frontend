
import React, { useState } from "react";

export default function App(){
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [token,setToken]=useState("");

  const API = "https://your-backend-url.com";

  const login = async ()=>{
    const res = await fetch(API+"/login",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({email,password})
    });
    const data = await res.json();
    setToken(data.token);
  };

  return(
    <div style={{padding:20}}>
      {!token ? (
        <>
          <input placeholder="email" onChange={e=>setEmail(e.target.value)} />
          <input placeholder="password" type="password" onChange={e=>setPassword(e.target.value)} />
          <button onClick={login}>Login</button>
        </>
      ):(
        <h2>Logged in</h2>
      )}
    </div>
  );
}
